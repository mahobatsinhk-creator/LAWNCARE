@php
    $home_posts = array_slice($blog_posts, 0, 3);
@endphp

@if ($home_posts !== [])
    <section id="blogs" class="harmone-home-blogs section-shell">
        <div class="harmone-home-blogs__inner section-inner">
            @include('partials.harmone-section-header', [
                'badge' => $home['blogs_badge'],
                'ctaHref' => route('blogs.index'),
                'ctaLabel' => $home['blogs_cta'],
                'ctaClass' => 'harmone-book-btn',
                'layout' => 'split',
            ])

            <div class="harmone-blogs-grid harmone-home-blogs__grid">
                @foreach ($home_posts as $post)
                    <article class="harmone-blog-card">
                        <a href="{{ route('blogs.show', $post['slug']) }}" class="harmone-blog-card__link">
                            <div class="harmone-blog-card__media">
                                <img src="{{ $post['image'] }}" alt="" loading="lazy">
                            </div>
                            <div class="harmone-blog-card__body">
                                <p class="harmone-blog-card__meta">
                                    <span>{{ $post['date'] }}</span>
                                </p>
                                <h3 class="harmone-blog-card__title">{{ $post['title'] }}</h3>
                                <span class="harmone-blog-card__arrow" aria-hidden="true">
                                    <img src="{{ $blog_arrow_icon }}" alt="" width="25" height="25">
                                </span>
                            </div>
                        </a>
                    </article>
                @endforeach
            </div>
        </div>
    </section>
@endif
